import asyncio
import json
import os
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from backend.app.demo.config import CONFIG, ROOT_DIR


try:
    import cv2
except ImportError:  # pragma: no cover - checked through status responses
    cv2 = None

try:
    import pytesseract
    from pytesseract import Output, TesseractNotFoundError
except ImportError:  # pragma: no cover - checked through status responses
    pytesseract = None
    Output = None
    TesseractNotFoundError = RuntimeError


CANVAS_SELECTOR = "canvas.market-grid-canvas__canvas"
MIN_ODDS = 1.01
MAX_ODDS = 100.0
OCR_MIN_CONFIDENCE = float(os.getenv("OCR_MIN_CONFIDENCE", "70"))
OCR_SCALE = 2.5
DIAGNOSTICS_DIR = ROOT_DIR / "backend" / "diagnostics" / "canvas"
ANALYSIS_FILE = DIAGNOSTICS_DIR / "latest_analysis.json"


class CanvasVisionError(RuntimeError):
    def __init__(self, status: str, message: str) -> None:
        super().__init__(message)
        self.status = status


def decode_canvas_image(image_bytes: bytes):
    if cv2 is None:
        raise CanvasVisionError("CV_ENGINE_NOT_AVAILABLE", "OpenCV не установлен.")
    image_array = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
    if image is None:
        raise CanvasVisionError("CANVAS_DECODE_ERROR", "OpenCV не декодировал PNG canvas.")
    return image


def preprocess_canvas(image) -> dict[str, Any]:
    if cv2 is None:
        raise CanvasVisionError("CV_ENGINE_NOT_AVAILABLE", "OpenCV не установлен.")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    scaled = cv2.resize(
        gray,
        None,
        fx=OCR_SCALE,
        fy=OCR_SCALE,
        interpolation=cv2.INTER_CUBIC,
    )
    _, threshold = cv2.threshold(
        scaled,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU,
    )
    adaptive = cv2.adaptiveThreshold(
        scaled,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        9,
    )
    return {
        "gray": gray,
        "scaled": scaled,
        "threshold": threshold,
        "adaptive": adaptive,
    }


def parse_odds(text: str) -> list[float]:
    values = []
    for token in re.findall(r"(?<!\d)\d{1,2}[.,]\d{1,3}(?!\d)", text):
        value = float(token.replace(",", "."))
        if MIN_ODDS <= value <= MAX_ODDS:
            values.append(value)
    return values


def _ensure_ocr() -> None:
    if pytesseract is None:
        raise CanvasVisionError(
            "OCR_ENGINE_NOT_AVAILABLE",
            "Python package pytesseract не установлен.",
        )
    try:
        pytesseract.get_tesseract_version()
    except (TesseractNotFoundError, OSError) as error:
        raise CanvasVisionError(
            "OCR_ENGINE_NOT_AVAILABLE",
            "Tesseract OCR executable не установлен или отсутствует в PATH.",
        ) from error


def detect_text_regions(image, numeric_only: bool = False) -> list[dict[str, Any]]:
    _ensure_ocr()
    config = "--psm 6"
    language = None
    if numeric_only:
        config += " -c tessedit_char_whitelist=0123456789.,"
    else:
        try:
            languages = set(pytesseract.get_languages(config=""))
            language = "rus+eng" if "rus" in languages else "eng"
        except Exception:
            language = "eng"

    data = pytesseract.image_to_data(
        image,
        lang=language,
        output_type=Output.DICT,
        config=config,
    )
    regions = []
    for index, raw_text in enumerate(data.get("text", [])):
        text = str(raw_text).strip()
        try:
            confidence = float(data["conf"][index])
        except (ValueError, TypeError, KeyError):
            confidence = -1
        if not text:
            continue
        regions.append(
            {
                "text": text,
                "x": int(data["left"][index]),
                "y": int(data["top"][index]),
                "width": int(data["width"][index]),
                "height": int(data["height"][index]),
                "confidence": confidence,
                "block": int(data["block_num"][index]),
                "paragraph": int(data["par_num"][index]),
                "line": int(data["line_num"][index]),
            }
        )
    return regions


def _deduplicate_candidates(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for candidate in sorted(candidates, key=lambda item: item["confidence"], reverse=True):
        duplicate = next(
            (
                item
                for item in result
                if item["value"] == candidate["value"]
                and abs(item["x"] - candidate["x"]) <= 12
                and abs(item["y"] - candidate["y"]) <= 12
            ),
            None,
        )
        if duplicate is None:
            result.append(candidate)
    return sorted(result, key=lambda item: (item["y"], item["x"]))


def extract_numeric_candidates(image) -> list[dict[str, Any]]:
    processed = preprocess_canvas(image)
    candidates: list[dict[str, Any]] = []

    for variant in ("scaled", "threshold", "adaptive"):
        for region in detect_text_regions(processed[variant], numeric_only=True):
            values = parse_odds(region["text"])
            if not values:
                continue
            for value in values:
                candidates.append(
                    {
                        "value": value,
                        "text": region["text"],
                        "x": round(region["x"] / OCR_SCALE),
                        "y": round(region["y"] / OCR_SCALE),
                        "width": round(region["width"] / OCR_SCALE),
                        "height": round(region["height"] / OCR_SCALE),
                        "confidence": round(region["confidence"], 2),
                        "variant": variant,
                        "usable": region["confidence"] >= OCR_MIN_CONFIDENCE,
                    }
                )

    return _deduplicate_candidates(candidates)


def _find_next_goal_lines(text_regions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    lines: dict[tuple[int, int, int], list[dict[str, Any]]] = {}
    for region in text_regions:
        key = (region["block"], region["paragraph"], region["line"])
        lines.setdefault(key, []).append(region)

    matches = []
    for regions in lines.values():
        regions.sort(key=lambda item: item["x"])
        text = " ".join(item["text"] for item in regions).lower().strip()
        if ("следующ" in text and "гол" in text) or "next goal" in text:
            left = min(item["x"] for item in regions)
            top = min(item["y"] for item in regions)
            right = max(item["x"] + item["width"] for item in regions)
            bottom = max(item["y"] + item["height"] for item in regions)
            matches.append(
                {
                    "text": text,
                    "x": round(left / OCR_SCALE),
                    "y": round(top / OCR_SCALE),
                    "width": round((right - left) / OCR_SCALE),
                    "height": round((bottom - top) / OCR_SCALE),
                    "confidence": round(
                        sum(item["confidence"] for item in regions) / len(regions),
                        2,
                    ),
                }
            )
    return matches


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def _save_diagnostics(
    image,
    processed: dict[str, Any],
    candidates: list[dict[str, Any]],
    timestamp: str,
) -> dict[str, str]:
    DIAGNOSTICS_DIR.mkdir(parents=True, exist_ok=True)
    paths = {
        "original": DIAGNOSTICS_DIR / f"canvas_original_{timestamp}.png",
        "gray": DIAGNOSTICS_DIR / f"canvas_gray_{timestamp}.png",
        "threshold": DIAGNOSTICS_DIR / f"canvas_threshold_{timestamp}.png",
        "ocr_boxes": DIAGNOSTICS_DIR / f"canvas_ocr_boxes_{timestamp}.png",
    }
    cv2.imwrite(str(paths["original"]), image)
    cv2.imwrite(str(paths["gray"]), processed["gray"])
    cv2.imwrite(str(paths["threshold"]), processed["threshold"])

    annotated = image.copy()
    for item in candidates:
        color = (63, 219, 147) if item["usable"] else (52, 165, 255)
        top_left = (item["x"], item["y"])
        bottom_right = (item["x"] + item["width"], item["y"] + item["height"])
        cv2.rectangle(annotated, top_left, bottom_right, color, 2)
        cv2.putText(
            annotated,
            f"{item['value']} ({item['confidence']:.0f})",
            (item["x"], max(12, item["y"] - 4)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            color,
            1,
            cv2.LINE_AA,
        )
    cv2.imwrite(str(paths["ocr_boxes"]), annotated)
    return {key: str(path.resolve()) for key, path in paths.items()}


async def capture_market_canvas(page) -> dict[str, Any]:
    canvas = page.locator(CANVAS_SELECTOR).first
    await canvas.wait_for(state="visible", timeout=10_000)
    box = await canvas.bounding_box()
    if box is None:
        raise CanvasVisionError("CANVAS_NOT_VISIBLE", "Canvas не имеет bounding box.")
    image_bytes = await canvas.screenshot()
    return {
        "bytes": image_bytes,
        "width": round(box["width"]),
        "height": round(box["height"]),
    }


async def analyze_market_canvas(page) -> dict[str, Any]:
    captured = await capture_market_canvas(page)
    image = decode_canvas_image(captured["bytes"])
    processed = preprocess_canvas(image)
    timestamp = _timestamp()

    candidates: list[dict[str, Any]] = []
    text_regions: list[dict[str, Any]] = []
    ocr_status = "OCR_COMPLETE"
    ocr_error = None
    try:
        candidates = await asyncio.to_thread(extract_numeric_candidates, image)
        text_regions = await asyncio.to_thread(
            detect_text_regions,
            processed["scaled"],
            False,
        )
    except CanvasVisionError as error:
        ocr_status = error.status
        ocr_error = str(error)

    next_goal_regions = _find_next_goal_lines(text_regions)
    paths = _save_diagnostics(image, processed, candidates, timestamp)
    analysis = {
        "ok": ocr_status == "OCR_COMPLETE",
        "status": "CANVAS_ANALYZED" if ocr_status == "OCR_COMPLETE" else ocr_status,
        "canvas": {"width": captured["width"], "height": captured["height"]},
        "numbers": candidates,
        "next_goal_regions": next_goal_regions,
        "ocr_min_confidence": OCR_MIN_CONFIDENCE,
        "diagnostics": paths,
        "error": ocr_error,
    }
    DIAGNOSTICS_DIR.mkdir(parents=True, exist_ok=True)
    ANALYSIS_FILE.write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")
    return analysis


def _stable_numeric_signature(analysis: dict[str, Any]) -> tuple[float, ...]:
    return tuple(
        sorted(
            round(float(item["value"]), 3)
            for item in analysis.get("numbers", [])
            if item.get("usable")
        )
    )


async def read_market_odds_from_canvas(page) -> dict[str, Any]:
    readings = []
    for index in range(3):
        readings.append(await analyze_market_canvas(page))
        if index < 2:
            await page.wait_for_timeout(150)

    signatures = [_stable_numeric_signature(item) for item in readings]
    confirmed = Counter(signatures).most_common(1)
    stable_signature = confirmed[0][0] if confirmed and confirmed[0][1] >= 2 else None
    latest = readings[-1]
    latest.update(
        readings=[
            {
                "status": item["status"],
                "numbers": item["numbers"],
                "signature": list(signature),
            }
            for item, signature in zip(readings, signatures, strict=True)
        ],
        stability="ODDS_CONFIRMED" if stable_signature is not None else "ODDS_UNSTABLE",
        stable_values=list(stable_signature) if stable_signature is not None else [],
    )
    ANALYSIS_FILE.write_text(json.dumps(latest, ensure_ascii=False, indent=2), encoding="utf-8")
    return latest


async def get_next_goal_odds(page, team1: str, team2: str) -> dict[str, Any]:
    analysis = await read_market_odds_from_canvas(page)
    if analysis["status"] != "CANVAS_ANALYZED":
        return {
            "ok": False,
            "status": analysis["status"],
            "source": "CANVAS_OCR",
            "confidence": None,
            "analysis": analysis,
        }
    if analysis["stability"] != "ODDS_CONFIRMED":
        return {
            "ok": False,
            "status": "ODDS_UNSTABLE",
            "source": "CANVAS_OCR",
            "confidence": None,
            "analysis": analysis,
        }
    if not analysis.get("next_goal_regions"):
        return {
            "ok": False,
            "status": "ODDS_MAPPING_UNCERTAIN",
            "source": "CANVAS_OCR",
            "confidence": None,
            "analysis": analysis,
        }

    # До анализа фактического canvas не связываем координаты с командами.
    return {
        "ok": False,
        "status": "ODDS_MAPPING_UNCERTAIN",
        "source": "CANVAS_OCR",
        "confidence": None,
        "team1": {"name": team1, "odds": None},
        "team2": {"name": team2, "odds": None},
        "analysis": analysis,
    }


def load_latest_analysis() -> dict[str, Any] | None:
    if not ANALYSIS_FILE.exists():
        return None
    try:
        return json.loads(ANALYSIS_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
