import json
import re
from typing import Any

from playwright.async_api import Page

from matches import (
    MATCH_SELECTOR,
    find_league_container,
    open_matches_page,
    parse_match,
    write_front,
)


class LeagueBrowser:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def open(self) -> None:
        await open_matches_page(self.page)
        container = await find_league_container(self.page)
        if container is None:
            raise RuntimeError("Контейнер целевой лиги не найден.")

    async def scan(self) -> list[dict[str, Any]]:
        container = await find_league_container(self.page)
        if container is None:
            raise RuntimeError("Контейнер целевой лиги не найден.")

        games = container.locator(MATCH_SELECTOR)
        candidates: list[dict[str, Any]] = []
        upcoming: list[dict[str, Any]] = []

        for index in range(await games.count()):
            item = await parse_match(games.nth(index), index + 1)
            if not item or item["finished"]:
                continue
            if item["is_upcoming"]:
                upcoming.append(item)
                candidates.append(item)
            elif item["period"]:
                # LIVE уже идёт: он приоритетнее будущего countdown.
                candidates.append(item)

        candidates.sort(
            key=lambda item: (
                0 if item["period"] else 1,
                item["time_seconds"] if item["time_seconds"] is not None else float("inf"),
            )
        )
        for number, item in enumerate(candidates, start=1):
            item["number"] = number

        upcoming.sort(key=lambda item: item["time_seconds"])
        for number, item in enumerate(upcoming, start=1):
            item["number"] = number
        await write_front(upcoming)

        return candidates

    async def open_match(self, match: dict[str, Any]) -> dict[str, str]:
        href = match.get("href")
        if not href:
            raise RuntimeError("У выбранного матча отсутствует href.")

        href_value = json.dumps(href)
        link = self.page.locator(
            f"a.dashboard-game-block__link[href={href_value}]"
        ).first
        await link.wait_for(state="visible", timeout=10_000)
        current_match_block = link.locator(
            "xpath=ancestor::li[contains(concat(' ', normalize-space(@class), ' '), "
            "' dashboard-champ__game ')][1]"
        )
        if await current_match_block.count() == 0:
            raise RuntimeError("Текущий блок выбранного матча не найден.")

        selector = "button.dashboard-game__more"
        more_button = current_match_block.locator(selector).first
        if await more_button.count() == 0:
            selector = "button.dashboard-game-more"
            more_button = current_match_block.locator(selector).first

        await more_button.wait_for(state="visible", timeout=10_000)
        await more_button.click()

        try:
            if match.get("match_id"):
                await self.page.wait_for_url(
                    re.compile(rf".*/{re.escape(match['match_id'])}-[^/?#]+.*"),
                    timeout=10_000,
                )
            else:
                await self.page.wait_for_timeout(1500)
        except Exception:
            # Кнопка может раскрыть рынки inline; точная ссылка остаётся
            # безопасным переходом именно в уже выбранный матч.
            await link.click()
            await self.page.wait_for_timeout(1500)

        return {"selector": selector, "url": self.page.url}
