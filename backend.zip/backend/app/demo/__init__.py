"""DEMO strategy engine."""
