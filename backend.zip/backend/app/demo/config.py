import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


ROOT_DIR = Path(__file__).resolve().parents[3]
load_dotenv(ROOT_DIR / ".env")


@dataclass(frozen=True)
class DemoConfig:
    mode: str = os.getenv("BET_MODE", "DEMO").strip().upper()
    league_url: str = os.getenv(
        "XBET_MATCHES_URL",
        "https://1xlite-02216.pro/ru/live/fifa/"
        "2860561-fc-25-3x3-conference-league",
    ).strip()
    league_name: str = os.getenv(
        "XBET_LEAGUE_NAME",
        "FC 25. 3x3. Лига Конференций",
    ).strip()
    score_poll_interval: float = float(
        os.getenv("SCORE_POLL_INTERVAL", "0.3")
    )
    league_retry_interval: float = float(
        os.getenv("MATCH_MONITOR_INTERVAL", "2")
    )
    data_dir: Path = ROOT_DIR / "backend" / "data"

    def validate(self) -> None:
        if self.mode != "DEMO":
            raise RuntimeError(
                "Режим REAL не реализован и заблокирован. Установите BET_MODE=DEMO."
            )
        if self.score_poll_interval < 0.1:
            raise RuntimeError("SCORE_POLL_INTERVAL не может быть меньше 0.1 сек.")


CONFIG = DemoConfig()
