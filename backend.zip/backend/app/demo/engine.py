import asyncio
from contextlib import suppress
from typing import Any
from uuid import uuid4

from playwright.async_api import Page, async_playwright

from auth import PROFILE_DIR, authorize

from backend.app.browser.league import LeagueBrowser
from backend.app.browser.market import (
    MarketDomRequired,
    MarketNotAvailable,
    MarketReadError,
    market_canvas_debug,
    read_next_goal_odds,
)
from backend.app.browser.canvas_vision import load_latest_analysis
from backend.app.browser.match import MatchBrowser
from backend.app.browser.scoreboard import ScoreReadError

from .config import CONFIG
from .history import REPOSITORY
from .models import DemoStatus, Score, Scorer, ScoreboardSnapshot, TeamSelection
from .state import STATE
from .strategy import (
    BET_STEPS,
    detect_scorer,
    odds_for_selected_side,
    select_team_with_higher_odds,
)


class DemoEngine:
    def __init__(self) -> None:
        self._task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()
        self._control_lock = asyncio.Lock()
        self._market_lock = asyncio.Lock()
        self._page: Page | None = None

    async def start(self) -> dict[str, Any]:
        async with self._control_lock:
            if self._task and not self._task.done():
                return await STATE.snapshot()

            CONFIG.validate()
            self._stop_event.clear()
            await STATE.reset_for_start(await REPOSITORY.stats())
            await REPOSITORY.log("DEMO_START", "Запущен background DEMO worker")
            self._task = asyncio.create_task(self._run_guarded(), name="demo-worker")
            return await STATE.snapshot()

    async def stop(self) -> dict[str, Any]:
        async with self._control_lock:
            self._stop_event.set()
            task = self._task

        if task and not task.done():
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=8)
            except TimeoutError:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task

        await REPOSITORY.log("DEMO_STOP", "DEMO worker остановлен")
        await STATE.update(
            running=False,
            status=DemoStatus.STOPPED.value,
            message="Демо остановлено",
            event="STOPPED",
        )
        return await STATE.snapshot()

    async def canvas_debug(self) -> dict[str, Any]:
        page = self._page
        if page is not None and not page.is_closed():
            async with self._market_lock:
                return await market_canvas_debug(page, REPOSITORY.log)

        cached = load_latest_analysis()
        if cached is None:
            return {
                "ok": False,
                "status": "NO_ACTIVE_MARKET_CANVAS",
                "error": "Сначала запустите DEMO worker и откройте матч.",
            }
        return {**cached, "cached": True}

    async def _run_guarded(self) -> None:
        try:
            await self._run()
        except asyncio.CancelledError:
            raise
        except Exception as error:
            await REPOSITORY.log("ERROR", str(error))
            await STATE.update(
                running=False,
                status=DemoStatus.ERROR.value,
                message="DEMO worker остановлен с ошибкой",
                error=str(error),
                event="ERROR",
            )
        finally:
            if self._stop_event.is_set():
                await STATE.update(running=False)

    async def _run(self) -> None:
        PROFILE_DIR.mkdir(parents=True, exist_ok=True)

        async with async_playwright() as playwright:
            context = await playwright.chromium.launch_persistent_context(
                user_data_dir=str(PROFILE_DIR),
                headless=False,
                viewport=None,
            )
            page = context.pages[0] if context.pages else await context.new_page()
            self._page = page
            try:
                auth_result = await authorize(page)
                if not auth_result.get("ok"):
                    raise RuntimeError(
                        "Авторизация не подтверждена: "
                        f"{auth_result.get('status', 'UNKNOWN')}"
                    )
                await REPOSITORY.log("AUTHORIZED", auth_result.get("status", "OK"))

                while not self._stop_event.is_set():
                    await self._process_next_match(page)
            finally:
                self._page = None
                await context.close()

    async def _process_next_match(self, page: Page) -> None:
        league = LeagueBrowser(page)
        await self._status(
            DemoStatus.OPENING_LEAGUE,
            "Открываем страницу лиги",
            "LEAGUE_OPENING",
        )
        await league.open()
        await REPOSITORY.log("LEAGUE_OPENED", CONFIG.league_name)

        matches: list[dict[str, Any]] = []
        while not matches and not self._stop_event.is_set():
            await self._status(
                DemoStatus.SCANNING_MATCHES,
                "Считываем актуальный DOM списка матчей",
                "MATCHES_REFRESHING",
            )
            matches = await league.scan()
            await REPOSITORY.log("MATCHES_FOUND", f"Найдено матчей: {len(matches)}")
            if not matches:
                await self._sleep_or_stop(CONFIG.league_retry_interval)

        if self._stop_event.is_set():
            return

        selected_match = matches[0]
        cycle_id = uuid4().hex
        match_name = f"{selected_match['team1']} — {selected_match['team2']}"
        await self._status(
            DemoStatus.MATCH_SELECTED,
            f"Выбран ближайший матч: {match_name}",
            "MATCH_SELECTED",
            match={
                "id": selected_match.get("match_id"),
                "team1": selected_match["team1"],
                "team2": selected_match["team2"],
                "score1": None,
                "score2": None,
                "timer": selected_match.get("time") or "",
                "period": selected_match.get("period") or "",
                "url": selected_match.get("url"),
            },
        )
        await REPOSITORY.log("MATCH_SELECTED", match_name)

        await self._status(
            DemoStatus.OPENING_MATCH,
            "Открываем выбранный матч",
            "MATCH_OPENING",
        )
        await REPOSITORY.log("OPENING_ADDITIONAL_MARKETS", "Opening additional markets")
        opened = await league.open_match(selected_match)
        await REPOSITORY.log(
            "ADDITIONAL_MARKETS_CLICKED",
            f"Clicked {opened['selector']}",
        )
        await REPOSITORY.log("MATCH_OPENED", page.url)

        browser = MatchBrowser(page)
        snapshot = await browser.snapshot()
        await self._publish_snapshot(snapshot, selected_match)
        await REPOSITORY.log(
            "INITIAL_SCORE",
            f"{snapshot.team1} — {snapshot.team2}: {snapshot.score.text()}",
        )

        await self._status(
            DemoStatus.READING_ODDS,
            "Читаем рынок «Следующий гол»",
            "READING_ODDS",
        )
        try:
            initial_odds = await self._read_odds(page, snapshot)
        except MarketReadError as error:
            analysis = error.details.get("analysis", {})
            numbers = analysis.get("numbers", [])
            confidences = [
                float(item["confidence"])
                for item in numbers
                if item.get("confidence") is not None
            ]
            await STATE.update(
                event=error.status,
                odds={
                    "selected": None,
                    "opponent": None,
                    "team1": None,
                    "team2": None,
                    "source": error.details.get("source", "CANVAS_OCR"),
                    "confidence": max(confidences) if confidences else None,
                    "status": error.status,
                },
            )
            raise
        selection = select_team_with_higher_odds(
            snapshot.team1,
            snapshot.team2,
            initial_odds,
        )
        await STATE.update(
            status=DemoStatus.TEAM_SELECTED.value,
            message=f"Выбрана команда {selection.selected_team}: коэффициент выше",
            event="TEAM_SELECTED",
            selected_team=selection.selected_team,
            other_team=selection.other_team,
            selection_reason="Коэффициент рынка «Следующий гол» выше",
            odds={
                "selected": selection.selected_odds,
                "opponent": selection.other_odds,
                "team1": initial_odds.team1,
                "team2": initial_odds.team2,
                "source": initial_odds.source,
                "confidence": initial_odds.confidence,
                "status": "ODDS_CONFIRMED",
            },
        )
        await REPOSITORY.log(
            "TEAM_SELECTED",
            f"{selection.selected_team} {selection.selected_odds} / "
            f"{selection.other_team} {selection.other_odds}",
        )

        won = False
        for step, amount in enumerate(BET_STEPS, start=1):
            if self._stop_event.is_set():
                return

            if step == 1:
                current_odds = initial_odds
            else:
                current_odds = await self._read_current_odds(
                    page,
                    snapshot,
                )

            selected_odd, opponent_odd = odds_for_selected_side(
                current_odds,
                selection.selected_side,
            )
            score_before = snapshot.score
            await STATE.update(
                status=DemoStatus.BET_SIMULATED.value,
                message=f"DEMO BET #{step}: {amount} RUB @ {selected_odd}",
                event="BET_SIMULATED",
                odds={
                    "selected": selected_odd,
                    "opponent": opponent_odd,
                    "team1": current_odds.team1,
                    "team2": current_odds.team2,
                    "source": current_odds.source,
                    "confidence": current_odds.confidence,
                    "status": "ODDS_CONFIRMED",
                },
                bet={
                    "step": step,
                    "max_steps": len(BET_STEPS),
                    "amount": amount,
                    "market": current_odds.market,
                    "odds": selected_odd,
                    "score_before": score_before.text(),
                    "next_goal_number": current_odds.next_goal_number,
                },
            )
            await REPOSITORY.log(
                "BET_SIMULATED",
                f"#{step}: {selection.selected_team}, {amount} RUB @ {selected_odd}, "
                f"счёт {score_before.text()}",
            )

            goal = await self._wait_for_goal(
                browser,
                selected_match,
                snapshot,
            )
            if goal is None:
                return
            new_snapshot, scorer = goal

            if scorer == Scorer.AMBIGUOUS_SCORE_CHANGE:
                await REPOSITORY.log(
                    scorer.value,
                    f"{score_before.text()} → {new_snapshot.score.text()}",
                )
                await REPOSITORY.add_cycle(
                    {
                        "cycle_id": cycle_id,
                        "match": match_name,
                        "result": scorer.value,
                        "steps": step,
                    }
                )
                await STATE.update(
                    status=DemoStatus.ERROR.value,
                    message="Неоднозначное изменение счёта; ставка не рассчитана",
                    event=scorer.value,
                    last_change={
                        "before": score_before.text(),
                        "after": new_snapshot.score.text(),
                        "scorer": "Не определён",
                        "result": scorer.value,
                    },
                )
                break

            scorer_name = (
                new_snapshot.team1 if scorer == Scorer.TEAM_1 else new_snapshot.team2
            )
            result = "WIN" if scorer == selection.selected_side else "LOSE"
            record = await REPOSITORY.add_bet(
                {
                    "cycle_id": cycle_id,
                    "match_id": selected_match.get("match_id"),
                    "match": match_name,
                    "selected_team": selection.selected_team,
                    "step": step,
                    "amount": amount,
                    "odds": selected_odd,
                    "score_before": score_before.text(),
                    "score_after": new_snapshot.score.text(),
                    "scorer": scorer_name,
                    "result": result,
                    "market": current_odds.market,
                    "next_goal_number": current_odds.next_goal_number,
                }
            )
            await REPOSITORY.log(
                "BET_RESULT",
                f"{score_before.text()} → {new_snapshot.score.text()}, "
                f"гол {scorer_name}, {result}",
            )
            await STATE.update(
                status=(DemoStatus.WIN if result == "WIN" else DemoStatus.LOSE).value,
                message=f"Результат виртуальной ставки: {result}",
                event="BET_RESULT",
                last_change={
                    "before": record["score_before"],
                    "after": record["score_after"],
                    "scorer": scorer_name,
                    "result": result,
                },
                stats=await REPOSITORY.stats(),
            )
            snapshot = new_snapshot

            if result == "WIN":
                won = True
                await REPOSITORY.add_cycle(
                    {
                        "cycle_id": cycle_id,
                        "match": match_name,
                        "result": "WIN",
                        "steps": step,
                    }
                )
                await REPOSITORY.log("STRATEGY_CYCLE_WON", match_name)
                break

            if step < len(BET_STEPS):
                await self._status(
                    DemoStatus.NEXT_STEP,
                    f"Переход к шагу {step + 1}",
                    "NEXT_STEP",
                )

        if not won and not self._stop_event.is_set():
            current = await STATE.snapshot()
            if current["status"] != DemoStatus.ERROR.value:
                await REPOSITORY.add_cycle(
                    {
                        "cycle_id": cycle_id,
                        "match": match_name,
                        "result": "BET_SEQUENCE_EXHAUSTED",
                        "steps": len(BET_STEPS),
                    }
                )
                await self._status(
                    DemoStatus.SEQUENCE_EXHAUSTED,
                    "Все 11 шагов исчерпаны",
                    "BET_SEQUENCE_EXHAUSTED",
                    stats=await REPOSITORY.stats(),
                )
                await REPOSITORY.log(
                    "BET_SEQUENCE_EXHAUSTED",
                    match_name,
                )

        if not self._stop_event.is_set():
            await self._status(
                DemoStatus.RETURNING_TO_LEAGUE,
                "Возвращаемся в лигу и обновляем список",
                "RETURNING_TO_LEAGUE",
                stats=await REPOSITORY.stats(),
            )
            await REPOSITORY.log("RETURNING_TO_LEAGUE", CONFIG.league_url)

    async def _read_current_odds(
        self,
        page: Page,
        snapshot: ScoreboardSnapshot,
    ):
        attempts = 0
        while not self._stop_event.is_set():
            try:
                return await self._read_odds(page, snapshot)
            except MarketNotAvailable as error:
                attempts += 1
                if attempts == 1 or attempts % 10 == 0:
                    await REPOSITORY.log("MARKET_WAIT", str(error))
                await self._sleep_or_stop(0.5)
            except MarketDomRequired:
                raise
        raise asyncio.CancelledError

    async def _read_odds(self, page: Page, snapshot: ScoreboardSnapshot):
        async with self._market_lock:
            return await read_next_goal_odds(
                page,
                snapshot.team1,
                snapshot.team2,
                REPOSITORY.log,
            )

    async def _wait_for_goal(
        self,
        browser: MatchBrowser,
        selected_match: dict[str, Any],
        previous: ScoreboardSnapshot,
    ) -> tuple[ScoreboardSnapshot, Scorer] | None:
        await self._status(
            DemoStatus.WAITING_FOR_GOAL,
            "Ожидаем числовое увеличение счёта",
            "WAITING_FOR_GOAL",
        )
        read_errors = 0

        while not self._stop_event.is_set():
            await self._sleep_or_stop(CONFIG.score_poll_interval)
            try:
                current = await browser.snapshot()
            except ScoreReadError as error:
                read_errors += 1
                if read_errors == 1 or read_errors % 20 == 0:
                    await REPOSITORY.log("SCORE_READ_ERROR", str(error))
                continue

            read_errors = 0
            if current.team1 != previous.team1 or current.team2 != previous.team2:
                raise RuntimeError("Порядок или названия команд в scoreboard изменились.")

            await self._publish_snapshot(current, selected_match)
            scorer = detect_scorer(previous.score, current.score)
            if scorer == Scorer.UNKNOWN:
                continue

            await STATE.update(
                status=DemoStatus.GOAL_DETECTED.value,
                message=f"Счёт изменился: {previous.score.text()} → {current.score.text()}",
                event="SCORE_CHANGED",
            )
            return current, scorer

        return None

    async def _publish_snapshot(
        self,
        snapshot: ScoreboardSnapshot,
        selected_match: dict[str, Any],
    ) -> None:
        match = snapshot.to_dict()
        match.update(
            id=selected_match.get("match_id"),
            url=selected_match.get("url"),
        )
        await STATE.update(match=match)

    async def _status(
        self,
        status: DemoStatus,
        message: str,
        event: str,
        **changes: Any,
    ) -> None:
        await STATE.update(
            status=status.value,
            message=message,
            event=event,
            error=None,
            **changes,
        )

    async def _sleep_or_stop(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop_event.wait(), timeout=seconds)
        except TimeoutError:
            pass


ENGINE = DemoEngine()
