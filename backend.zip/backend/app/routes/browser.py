from fastapi import APIRouter

from backend.app.demo.engine import ENGINE


router = APIRouter(prefix="/api/browser", tags=["browser"])


@router.post("/market-canvas-debug")
async def market_canvas_debug():
    return await ENGINE.canvas_debug()
